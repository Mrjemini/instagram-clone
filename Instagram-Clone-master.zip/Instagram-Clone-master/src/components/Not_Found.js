import React from "react";
import Not_Found1 from "../images/404.svg";

const Not_Found = () => {
  return (
    <div>
      <img src={Not_Found1} className="found_image" />
    </div>
  );
};

export default Not_Found;
